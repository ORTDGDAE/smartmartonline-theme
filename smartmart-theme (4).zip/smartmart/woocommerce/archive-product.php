<?php
/**
 * The Template for displaying product archives
 *
 * @package SmartMart
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' ); ?>

<div id="primary" class="container site-content">
    <main id="main" class="site-main">

        <div class="woocommerce-archive-header">
            <div class="woocommerce-archive-header-top">
                <h1 class="woocommerce-products-header__title page-title"><?php woocommerce_page_title(); ?></h1>
                <?php woocommerce_catalog_ordering(); ?>
            </div>
            <?php
            do_action( 'woocommerce_archive_description' );
            ?>
        </div>

        <div class="woocommerce-archive-layout">
            <?php if ( is_active_sidebar( 'sidebar-shop' ) ) : ?>
                <aside class="woocommerce-sidebar">
                    <?php dynamic_sidebar( 'sidebar-shop' ); ?>
                </aside>
            <?php endif; ?>

            <div class="woocommerce-products-area">
                <?php
                if ( woocommerce_product_loop() ) {
                    do_action( 'woocommerce_before_shop_loop' );
                    woocommerce_product_loop_start();

                    if ( wc_get_loop_prop( 'total' ) ) {
                        while ( have_posts() ) {
                            the_post();
                            do_action( 'woocommerce_shop_loop' );
                            wc_get_template_part( 'content', 'product' );
                        }
                    }

                    woocommerce_product_loop_end();
                    do_action( 'woocommerce_after_shop_loop' );
                } else {
                    do_action( 'woocommerce_no_products_found' );
                }
                ?>
            </div>
        </div>

    </main>
</div>

<?php get_footer( 'shop' ); ?>
