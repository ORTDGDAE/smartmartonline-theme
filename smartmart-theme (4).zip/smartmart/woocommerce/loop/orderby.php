<?php
/**
 * Show options for ordering
 *
 * @package SmartMart
 */

defined( 'ABSPATH' ) || exit;

$catalog_orderby_options = apply_filters( 'woocommerce_catalog_orderby', array(
    'menu_order' => __( 'Default sorting', 'smartmart' ),
    'popularity' => __( 'Sort by popularity', 'smartmart' ),
    'rating'     => __( 'Sort by average rating', 'smartmart' ),
    'date'       => __( 'Sort by latest', 'smartmart' ),
    'price'      => __( 'Sort by price: low to high', 'smartmart' ),
    'price-desc' => __( 'Sort by price: high to low', 'smartmart' ),
) );

$default_orderby = wc_get_loop_prop( 'is_search' ) ? 'relevance' : apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby', 'menu_order' ) );

$orderby = isset( $_GET['orderby'] ) ? wc_clean( $_GET['orderby'] ) : $default_orderby;

if ( wc_get_loop_prop( 'is_search' ) ) {
    $catalog_orderby_options = array_merge( array( 'relevance' => __( 'Relevance', 'smartmart' ) ), $catalog_orderby_options );
    unset( $catalog_orderby_options['menu_order'] );
}
?>
<form class="woocommerce-ordering" method="get">
    <select name="orderby" class="orderby" aria-label="<?php esc_attr_e( 'Shop order', 'smartmart' ); ?>">
        <?php foreach ( $catalog_orderby_options as $id => $name ) : ?>
            <option value="<?php echo esc_attr( $id ); ?>" <?php selected( $orderby, $id ); ?>><?php echo esc_html( $name ); ?></option>
        <?php endforeach; ?>
    </select>
    <input type="hidden" name="paged" value="1" />
    <?php wc_query_string_form_fields( null, array( 'orderby', 'submit', 'paged', 'product-page' ) ); ?>
</form>
