<?php
/**
 * Product Loop Start
 *
 * @package SmartMart
 */
?>
<ul class="products columns-<?php echo esc_attr( wc_get_loop_prop( 'columns' ) ); ?>">
