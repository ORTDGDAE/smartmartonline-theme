<?php
/**
 * Result Count
 *
 * @package SmartMart
 */

defined( 'ABSPATH' ) || exit;

$total    = wc_get_loop_prop( 'total' );
$per_page = wc_get_loop_prop( 'per_page' );
$current  = wc_get_loop_prop( 'current_page' );
$offset   = ( $current - 1 ) * $per_page;

if ( $total <= $per_page || -1 === $per_page ) {
    return;
}
?>
<p class="woocommerce-result-count">
    <?php
    if ( 1 === $total ) {
        esc_html_e( 'Showing the single result', 'smartmart' );
    } elseif ( $total <= $per_page || -1 === $per_page ) {
        printf( esc_html__( 'Showing all %d results', 'smartmart' ), $total );
    } else {
        $first = $offset + 1;
        $last  = min( $offset + $per_page, $total );
        printf( esc_html__( 'Showing %1$d&ndash;%2$d of %3$d results', 'smartmart' ), $first, $last, $total );
    }
    ?>
</p>
