<?php
/**
 * The Template for displaying single product
 *
 * @package SmartMart
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' ); ?>

<div id="primary" class="container site-content">
    <main id="main" class="site-main">
        <?php while ( have_posts() ) : the_post(); ?>
            <?php wc_get_template_part( 'content', 'single-product' ); ?>
        <?php endwhile; ?>
    </main>
</div>

<?php get_footer( 'shop' ); ?>
