/**
 * SmartMart Navigation - Keyboard accessibility
 *
 * @package SmartMart
 * @since   1.0.0
 */
(function () {
    'use strict';

    var menuItems = document.querySelectorAll('.main-navigation li.menu-item-has-children > a');

    for (var i = 0; i < menuItems.length; i++) {
        menuItems[i].addEventListener('click', function (e) {
            var parent = this.parentElement;
            if (parent.classList.contains('focus')) {
                parent.classList.remove('focus');
            } else {
                // Close other open menus
                var openMenus = document.querySelectorAll('.main-navigation li.menu-item-has-children.focus');
                for (var j = 0; j < openMenus.length; j++) {
                    openMenus[j].classList.remove('focus');
                }
                parent.classList.add('focus');
            }
        });
    }

    // Close menus on Escape key
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            var openMenus = document.querySelectorAll('.main-navigation li.menu-item-has-children.focus');
            for (var j = 0; j < openMenus.length; j++) {
                openMenus[j].classList.remove('focus');
            }
            // Also close mobile menu
            var mobileToggle = document.querySelector('.menu-toggle');
            if (mobileToggle && mobileToggle.getAttribute('aria-expanded') === 'true') {
                mobileToggle.setAttribute('aria-expanded', 'false');
                mobileToggle.focus();
            }
        }
    });
})();
