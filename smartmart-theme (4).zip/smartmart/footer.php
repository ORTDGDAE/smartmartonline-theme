<?php
/**
 * The footer template
 *
 * @package SmartMart
 */
?>
</main><!-- .site-main -->

<footer class="site-footer" role="contentinfo">
    <div class="footer-inner">
        <?php if ( is_active_sidebar( 'sidebar-footer' ) ) : ?>
            <div class="footer-widgets">
                <div class="footer-brand">
                    <div class="site-logo" aria-hidden="true">
                        <span>SM</span>
                    </div>
                    <p><?php esc_html_e( 'Premium groceries and household essentials for modern living.', 'smartmart' ); ?></p>
                </div>
                <div class="footer-widgets-grid">
                    <?php dynamic_sidebar( 'sidebar-footer' ); ?>
                </div>
            </div>
        <?php else : ?>
            <div class="footer-widgets">
                <div class="footer-brand">
                    <div class="site-logo" aria-hidden="true">
                        <span>SM</span>
                    </div>
                    <p><?php esc_html_e( 'Premium groceries and household essentials for modern living.', 'smartmart' ); ?></p>
                </div>
                <div class="footer-widgets-grid">
                    <div class="widget">
                        <h4 class="widget-title"><?php esc_html_e( 'Shop', 'smartmart' ); ?></h4>
                        <ul>
                            <?php if ( class_exists( 'WooCommerce' ) ) : ?>
                                <li><a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>"><?php esc_html_e( 'All Products', 'smartmart' ); ?></a></li>
                            <?php endif; ?>
                            <li><a href="#"><?php esc_html_e( 'Organic Produce', 'smartmart' ); ?></a></li>
                            <li><a href="#"><?php esc_html_e( 'Pantry', 'smartmart' ); ?></a></li>
                        </ul>
                    </div>
                    <div class="widget">
                        <h4 class="widget-title"><?php esc_html_e( 'Company', 'smartmart' ); ?></h4>
                        <ul>
                            <li><a href="#"><?php esc_html_e( 'About Us', 'smartmart' ); ?></a></li>
                            <li><a href="#"><?php esc_html_e( 'Sustainability', 'smartmart' ); ?></a></li>
                            <li><a href="#"><?php esc_html_e( 'Contact', 'smartmart' ); ?></a></li>
                        </ul>
                    </div>
                    <div class="widget">
                        <h4 class="widget-title"><?php esc_html_e( 'Support', 'smartmart' ); ?></h4>
                        <ul>
                            <li><a href="#"><?php esc_html_e( 'Shipping', 'smartmart' ); ?></a></li>
                            <li><a href="#"><?php esc_html_e( 'Returns', 'smartmart' ); ?></a></li>
                            <li><a href="#"><?php esc_html_e( 'Track Order', 'smartmart' ); ?></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="footer-bottom">
            <div class="footer-copyright">
                &copy; <?php echo esc_html( date( 'Y' ) ); ?> <?php esc_html_e( 'SmartMart Online. All rights reserved.', 'smartmart' ); ?>
            </div>
            <div class="footer-bottom-links">
                <a href="#"><?php esc_html_e( 'Privacy', 'smartmart' ); ?></a>
                <a href="#"><?php esc_html_e( 'Terms', 'smartmart' ); ?></a>
            </div>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
