=== SmartMart ===
Contributors: ORTDGDAE
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Premium WooCommerce theme for online grocery and household shopping. Beautiful product cards, responsive grids, and an elevated shopping experience.

== Description ==

SmartMart is a beautiful, fully-customized WooCommerce theme designed for premium groceries and household essentials. It features a clean, modern design with a warm emerald-green color palette, smooth hover animations, and responsive product grids perfect for e-commerce stores.

= Key Features =

* Stunning Product Cards - Beautiful cards with hover animations, sale badges, and smooth image zooms
* Flexible Responsive Grids - Adaptive product layouts from 1 to 5 columns depending on screen size
* WooCommerce Integration - Fully compatible with WooCommerce including HPOS, cart, checkout, and account pages
* Accessibility Ready - Skip links, keyboard focus styles, and screen reader optimized
* Translation Ready - All strings are internationalized with text domain smartmart
* Customizable - Custom logo support, custom menus, widget areas, and CSS custom properties
* Clean Design - Emerald-green palette with Inter and Playfair Display fonts

== Frequently Asked Questions ==

= Does this theme require WooCommerce? =

No, but it is optimized for WooCommerce. Without WooCommerce, the theme still works as a clean blog theme.

= Is the theme translation-ready? =

Yes. All text strings are internationalized and wrapped in gettext functions. The text domain is 'smartmart'.

= How do I customize the colors? =

SmartMart uses CSS custom properties. You can override the --smo-primary, --smo-primary-dark, and other variables via Appearance > Customize > Additional CSS.

= Does this theme support block editor? =

Yes. SmartMart supports WordPress block editor styles, wide alignments, and responsive embeds.

== Installation ==

1. Upload the smartmart folder to the /wp-content/themes/ directory
2. Activate the theme through the Appearance > Themes menu in WordPress
3. Install and activate WooCommerce for full e-commerce functionality
4. Go to Appearance > Customize to configure your site

== Changelog ==

= 1.1.0 =
* Initial release on WordPress.org Theme Directory
* Full WooCommerce integration with HPOS compatibility
* Responsive product grids with hover animations
* Accessibility skip link and keyboard focus styles
* Custom logo, menu, and widget area support
* Internationalization support with text domain
* Search form, 404, and archive templates

= 1.0.0 =
* Initial development version

== Upgrade Notice ==

= 1.1.0 =
* Initial release for WordPress.org.

== Privacy ==

This theme does not collect, store, or transmit any personally identifiable user data. No external services are loaded without user consent.

Google Fonts (Inter and Playfair Display) are loaded from Google's CDN for typography.

== Resources ==

The following third-party resources are used by this theme:

* Inter Font - Google Fonts - https://fonts.google.com/specimen/Inter - SIL Open Font License 1.1
* Playfair Display Font - Google Fonts - https://fonts.google.com/specimen/Playfair+Display - SIL Open Font License 1.1

== Importing Demo Products ==

This theme includes starter CSV files to quickly populate your store with demo products.

See `starter-content/IMPORT-GUIDE.md` for step-by-step instructions.

CSV files included:
* `starter-content/smartmart-products.csv` - 33 grocery products across 6 categories
* `starter-content/smartmart-categories.csv` - 17 categories with subcategories

How to import:
1. Install and activate WooCommerce
2. Go to WooCommerce > Products > Import
3. Upload the products CSV file
4. Map the columns and run the importer
5. Repeat for categories CSV if needed
6. The theme will display them beautifully!
