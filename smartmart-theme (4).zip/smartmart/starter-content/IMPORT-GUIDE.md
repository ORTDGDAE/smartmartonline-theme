# SmartMart Demo Content Import Guide

## WooCommerce CSV Import (Recommended)

SmartMart includes **170 products** across **17 categories** ready for import.

### Step-by-Step:

1. **Install WooCommerce** (Plugins → Add New → "WooCommerce")
2. **Run WooCommerce Setup Wizard** or skip it
3. **Import Products**:
   - Go to **WooCommerce → Products → Import**
   - Choose CSV file: `starter-content/smartmart-products.csv`
   - Column mapping should auto-detect ✅
   - Click **"Run the Importer"**
4. **Import Categories** (if needed):
   - Go to **WooCommerce → Products → Categories**
   - Use bulk add, or the CSV via **Tools → Import**
5. **Set Homepage**:
   - Settings → Reading → "A static page"
   - Select "Front Page"
6. **Set Menus**:
   - Appearance → Menus
   - Create Primary Menu (Home, Shop, Collections)
   - Set as "Primary Menu" location

## Products Included (170 total)

| # | Category | Products | Price Range | 
|---|----------|----------|-------------|
| 1 | 🥬 **Produce** | Bananas, Strawberries, Tomatoes, Spinach, Avocados, Blueberries, Bell Peppers, Sweet Potatoes, Broccoli, Grapes | $1.79 - $4.99 |
| 2 | 🍎 **Fruits** | Apples, Oranges, Mangoes, Kiwi, Lemons, Pineapple, Raspberries, Watermelon, Gala Apples, Dragon Fruit | $0.79 - $5.99 |
| 3 | 🥦 **Vegetables** | Carrots, Cucumber, Zucchini, Red Onions, Cauliflower, Asparagus, Kale, Mushrooms, Butternut Squash, Celery | $1.99 - $4.49 |
| 4 | 🥛 **Dairy & Eggs** | Milk, Eggs, Yogurt, Cheddar, Butter, Almond Milk, Mozzarella, Heavy Cream, Cottage Cheese, Sour Cream | $2.99 - $5.99 |
| 5 | 🥐 **Bakery** | Sourdough, Croissants, Wheat Bread, Muffins, Cinnamon Rolls, Baguette, Choc Croissant, Banana Bread, Bagels, Focaccia | $3.49 - $6.49 |
| 6 | 🍞 **Bread** | Rye, Brioche, Ciabatta, GF Bread, Pretzel Rolls, English Muffins, Pita, Challah, Cornbread, Olive Bread | $3.49 - $6.99 |
| 7 | 🥮 **Pastries** | Danish, Turnover, Palmiers, Macarons, Scones, Cannoli, Bear Claw, Éclair, Baklava, Tiramisu | $3.49 - $8.99 |
| 8 | 🍝 **Pantry** | Rice, Olive Oil, Pasta, Chickpeas, Honey, Granola, PB, Quinoa, Coconut Milk, Soy Sauce | $1.79 - $12.99 |
| 9 | 🌾 **Grains & Pasta** | Jasmine Rice, Couscous Pearl, Linguine, Penne, Farfalle, Oats, Couscous, Soba, Arborio, Ramen | $2.49 - $8.99 |
| 10 | 🫒 **Oils & Vinegars** | Avocado Oil, Balsamic, Sesame Oil, Coconut Oil, Red Wine Vinegar, Truffle Oil, ACV, Grapeseed, Rice Vinegar, Chili Oil | $3.99 - $14.99 |
| 11 | 🥫 **Canned & Jarred** | Diced Tomatoes, Coconut Cream, Artichokes, Black Beans, Tuna, Tomato Paste, Pumpkin, Sardines, Roasted Peppers, Chipotles | $1.49 - $4.99 |
| 12 | ☕ **Beverages** | Cold Brew, Green Tea, OJ, Sparkling Water, Matcha, Kombucha, Coconut Water, Ginger Shot, Chai, Lemonade | $3.49 - $14.99 |
| 13 | 🫖 **Coffee & Tea** | Ethiopian Coffee, Espresso, Earl Grey, Chamomile, Decaf, Peppermint, Matcha Latte, Chai Rooibos, Pour Over Kit, Jasmine | $4.29 - $14.99 |
| 14 | 🧃 **Juices** | Apple, Pomegranate, Carrot, Cranberry, Green, Beet, Grape, Watermelon, Tropical, Tomato | $3.99 - $6.99 |
| 15 | 🧹 **Household** | Detergent, Paper Towels, Dish Soap, Tote Bags, Bamboo Towels, All-Purpose, Trash Bags, Sponges, Spray Bottle, Microfiber Cloths | $2.99 - $8.99 |
| 16 | 🧽 **Cleaning** | Bathroom, Glass, Floor, Dish Pods, Stainless Polish, Dusting, Oven, Toilet, Carpet, Stain Stick | $3.49 - $6.99 |
| 17 | 🔪 **Kitchen** | Spatulas, Measuring Cups, Food Storage, Tongs, Zester, Paring Knife, Cutting Board, Mixing Bowls, Peeler, Can Opener | $4.99 - $14.99 |

## All Products CSV Columns

- **Type**: simple (all products)
- **Published**: 1 (published)
- **Visibility**: visible (catalog & search)
- **Tax**: taxable (standard rate)
- **Stock**: In stock with quantities
- **Reviews**: Allowed on all products
- **Categories**: Uses the category slugs above

### WooCommerce HPOS Compatible
SmartMart theme fully supports WooCommerce High-Performance Order Storage.
