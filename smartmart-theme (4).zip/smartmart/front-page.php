<?php
/**
 * Front Page Template
 *
 * @package SmartMart
 */

get_header(); ?>

<div id="primary" class="container site-content">
    <main id="main" class="site-main">

        <!-- Hero Section -->
        <section class="hero-section">
            <h1 class="heading-serif">
                <?php esc_html_e( 'Elevated essentials.', 'smartmart' ); ?>
                <br>
                <span style="color:var(--smo-primary);"><?php esc_html_e( 'Every day.', 'smartmart' ); ?></span>
            </h1>
            <p>
                <?php esc_html_e( 'Thoughtfully curated groceries and premium household goods for the modern home and university lifestyle.', 'smartmart' ); ?>
            </p>
            <div class="hero-actions">
                <?php if ( class_exists( 'WooCommerce' ) ) : ?>
                    <a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>" class="btn-smartmart">
                        <?php esc_html_e( 'SHOP NOW', 'smartmart' ); ?>
                    </a>
                <?php endif; ?>
                <a href="#featured-categories" class="btn-smartmart btn-smartmart-outline">
                    <?php esc_html_e( 'Explore Collections', 'smartmart' ); ?>
                </a>
            </div>
        </section>

        <!-- Featured Categories -->
        <section id="featured-categories" style="padding:3rem 0;">
            <h2 style="text-align:center;font-size:2rem;margin-bottom:2.5rem;">
                <?php esc_html_e( 'Shop by Category', 'smartmart' ); ?>
            </h2>

            <?php if ( class_exists( 'WooCommerce' ) ) : ?>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1.5rem;">
                <?php
                $featured_cats = array( 'produce', 'dairy', 'bakery', 'pantry', 'beverages', 'household' );
                foreach ( $featured_cats as $cat_slug ) :
                    $category = get_term_by( 'slug', $cat_slug, 'product_cat' );
                    if ( ! $category ) {
                        continue;
                    }
                    $thumbnail_id = get_term_meta( $category->term_id, 'thumbnail_id', true );
                    $image = $thumbnail_id ? wp_get_attachment_url( $thumbnail_id ) : '';
                    $count = $category->count;
                ?>
                    <a href="<?php echo esc_url( get_term_link( $category ) ); ?>"
                       style="background:#fff;border:1px solid var(--smo-border);border-radius:1.5rem;padding:2rem;text-align:center;text-decoration:none;color:var(--smo-text);transition:all 0.3s ease;display:block;"
                       onmouseover="this.style.transform='translateY(-4px)';this.style.boxShadow='var(--smo-shadow)';"
                       onmouseout="this.style.transform='';this.style.boxShadow='';">
                        <div style="font-size:3rem;margin-bottom:1rem;">
                            <?php
                            $icons = array(
                                'produce'    => '🥬',
                                'dairy'      => '🥛',
                                'bakery'     => '🥐',
                                'pantry'     => '🍝',
                                'beverages'  => '☕',
                                'household'  => '🧹',
                            );
                            echo isset( $icons[ $cat_slug ] ) ? $icons[ $cat_slug ] : '🛒';
                            ?>
                        </div>
                        <h3 style="margin:0 0 0.5rem;font-size:1.25rem;"><?php echo esc_html( $category->name ); ?></h3>
                        <p style="margin:0;font-size:0.875rem;color:var(--smo-text-muted);">
                            <?php printf( esc_html( _n( '%d item', '%d items', $count, 'smartmart' ) ), (int) $count ); ?>
                        </p>
                    </a>
                <?php endforeach; ?>
            </div>
            <?php else : ?>
                <p style="text-align:center;color:var(--smo-text-muted);">
                    <?php esc_html_e( 'Install WooCommerce to display product categories here.', 'smartmart' ); ?>
                </p>
            <?php endif; ?>
        </section>

        <!-- Features Strip -->
        <section style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:2rem;padding:3rem 0;border-top:1px solid var(--smo-border);">
            <div style="text-align:center;">
                <div style="font-size:2rem;margin-bottom:0.75rem;">🚚</div>
                <h4 style="margin:0 0 0.25rem;"><?php esc_html_e( 'Free Delivery', 'smartmart' ); ?></h4>
                <p style="margin:0;font-size:0.875rem;color:var(--smo-text-muted);"><?php esc_html_e( 'On orders over $35', 'smartmart' ); ?></p>
            </div>
            <div style="text-align:center;">
                <div style="font-size:2rem;margin-bottom:0.75rem;">🌿</div>
                <h4 style="margin:0 0 0.25rem;"><?php esc_html_e( '100% Organic', 'smartmart' ); ?></h4>
                <p style="margin:0;font-size:0.875rem;color:var(--smo-text-muted);"><?php esc_html_e( 'Certified farm-fresh', 'smartmart' ); ?></p>
            </div>
            <div style="text-align:center;">
                <div style="font-size:2rem;margin-bottom:0.75rem;">♻️</div>
                <h4 style="margin:0 0 0.25rem;"><?php esc_html_e( 'Eco Packaging', 'smartmart' ); ?></h4>
                <p style="margin:0;font-size:0.875rem;color:var(--smo-text-muted);"><?php esc_html_e( '100% recyclable', 'smartmart' ); ?></p>
            </div>
            <div style="text-align:center;">
                <div style="font-size:2rem;margin-bottom:0.75rem;">⭐</div>
                <h4 style="margin:0 0 0.25rem;"><?php esc_html_e( 'Premium Quality', 'smartmart' ); ?></h4>
                <p style="margin:0;font-size:0.875rem;color:var(--smo-text-muted);"><?php esc_html_e( 'Hand-selected goods', 'smartmart' ); ?></p>
            </div>
        </section>

    </main>
</div>

<?php get_footer(); ?>
