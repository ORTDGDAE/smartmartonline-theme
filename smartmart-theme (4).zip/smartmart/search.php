<?php
/**
 * The template for displaying search results
 *
 * @package SmartMart
 */

get_header(); ?>

<div id="primary" class="container site-content">
    <main id="main" class="site-main">

        <header class="page-header">
            <h1 class="page-title">
                <?php
                printf(
                    esc_html__( 'Search Results for: %s', 'smartmart' ),
                    '<span>' . get_search_query() . '</span>'
                );
                ?>
            </h1>
        </header>

        <?php if ( have_posts() ) : ?>
            <div class="posts-grid">
                <?php while ( have_posts() ) : the_post(); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>
                        <div class="post-card-content">
                            <h2 class="entry-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h2>
                            <div class="entry-summary"><?php the_excerpt(); ?></div>
                            <a href="<?php the_permalink(); ?>" class="btn-smartmart btn-smartmart-outline"><?php esc_html_e( 'Read More', 'smartmart' ); ?></a>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>

            <?php the_posts_pagination(); ?>

        <?php else : ?>
            <p><?php esc_html_e( 'No results found. Try a different search.', 'smartmart' ); ?></p>
            <?php get_search_form(); ?>
        <?php endif; ?>

    </main>
</div>

<?php get_footer(); ?>
