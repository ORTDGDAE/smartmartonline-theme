<?php
/**
 * The main template file
 *
 * @package SmartMart
 */

get_header(); ?>

<div id="primary" class="container site-content">
    <main id="main" class="site-main">

        <?php if ( is_home() && ! is_front_page() ) : ?>
            <header class="page-header">
                <h1 class="page-title"><?php single_post_title(); ?></h1>
            </header>
        <?php endif; ?>

        <?php if ( have_posts() ) : ?>

            <div class="posts-grid">
                <?php while ( have_posts() ) : the_post(); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>
                        <?php if ( has_post_thumbnail() ) : ?>
                            <div class="post-thumbnail">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail( 'medium' ); ?>
                                </a>
                            </div>
                        <?php endif; ?>

                        <div class="post-card-content">
                            <header class="entry-header">
                                <?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h2>' ); ?>
                            </header>

                            <div class="entry-meta">
                                <span class="posted-on">
                                    <?php echo esc_html( get_the_date() ); ?>
                                </span>
                                <span class="byline">
                                    <?php esc_html_e( 'by', 'smartmart' ); ?>
                                    <?php the_author(); ?>
                                </span>
                            </div>

                            <div class="entry-summary">
                                <?php the_excerpt(); ?>
                            </div>

                            <a href="<?php the_permalink(); ?>" class="btn-smartmart btn-smartmart-outline">
                                <?php esc_html_e( 'Read More', 'smartmart' ); ?>
                            </a>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>

            <?php the_posts_pagination(); ?>

        <?php else : ?>
            <p><?php esc_html_e( 'No posts found.', 'smartmart' ); ?></p>
        <?php endif; ?>

    </main>
</div>

<?php get_footer(); ?>
