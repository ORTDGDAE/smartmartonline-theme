<?php
/**
 * The header template
 *
 * @package SmartMart
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link" href="#main">
    <?php esc_html_e( 'Skip to main content', 'smartmart' ); ?>
</a>

<header class="site-header" role="banner">
    <div class="header-inner">
        <div class="site-branding">
            <div class="site-logo" aria-hidden="true">
                <span>SM</span>
            </div>
            <div>
                <?php if ( has_custom_logo() ) : ?>
                    <?php the_custom_logo(); ?>
                <?php else : ?>
                    <p class="site-title">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                            <?php bloginfo( 'name' ); ?>
                        </a>
                    </p>
                <?php endif; ?>
                <span class="site-tagline"><?php echo esc_html( get_bloginfo( 'description' ) ); ?></span>
            </div>
        </div>

        <nav class="main-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'smartmart' ); ?>">
            <?php
            if ( has_nav_menu( 'primary' ) ) {
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'container'      => false,
                    'menu_class'     => 'primary-menu',
                    'fallback_cb'    => false,
                    'depth'          => 3,
                ) );
            } else {
                ?>
                <ul class="primary-menu">
                    <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'smartmart' ); ?></a></li>
                    <?php if ( class_exists( 'WooCommerce' ) ) : ?>
                        <li><a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>"><?php esc_html_e( 'Shop', 'smartmart' ); ?></a></li>
                    <?php endif; ?>
                </ul>
                <?php
            }
            ?>
        </nav>

        <div class="header-actions">
            <div class="header-search">
                <?php get_search_form(); ?>
            </div>

            <?php if ( class_exists( 'WooCommerce' ) ) : ?>
                <a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="header-cart" aria-label="<?php esc_attr_e( 'View shopping cart', 'smartmart' ); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/>
                        <line x1="3" y1="6" x2="21" y2="6"/>
                        <path d="M16 10a4 4 0 0 1-8 0"/>
                    </svg>
                    <span><?php esc_html_e( 'Cart', 'smartmart' ); ?></span>
                    <span class="header-cart-count">
                        <?php echo WC()->cart ? (int) WC()->cart->get_cart_contents_count() : 0; ?>
                    </span>
                </a>
            <?php endif; ?>
        </div>
    </div>
</header>

<main id="main" class="site-main">
