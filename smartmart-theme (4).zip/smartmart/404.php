<?php
/**
 * The template for displaying 404 pages
 *
 * @package SmartMart
 */

get_header(); ?>

<div id="primary" class="container site-content">
    <main id="main" class="site-main">
        <section class="error-404 not-found text-center" style="padding:4rem 0;text-align:center;">
            <h1 class="page-title" style="font-size:5rem;margin-bottom:0.5rem;">404</h1>
            <p style="font-size:1.25rem;color:var(--smo-text-muted);margin-bottom:2rem;">
                <?php esc_html_e( 'Oops! That page could not be found.', 'smartmart' ); ?>
            </p>
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn-smartmart">
                <?php esc_html_e( 'Go Home', 'smartmart' ); ?>
            </a>
        </section>
    </main>
</div>

<?php get_footer(); ?>
