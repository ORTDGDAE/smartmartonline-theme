<?php
/**
 * SmartMart Theme Functions
 *
 * @package SmartMart
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'SMARTMART_VERSION', '1.1.0' );

/**
 * Theme setup.
 */
function smartmart_setup() {
    // Translation-ready.
    load_theme_textdomain( 'smartmart', get_template_directory() . '/languages' );

    // WooCommerce support.
    add_theme_support( 'woocommerce' );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );

    // Core WordPress features.
    add_theme_support( 'title-tag' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'custom-logo', array(
        'height'      => 60,
        'width'       => 240,
        'flex-height' => true,
        'flex-width'  => true,
    ) );
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ) );
    add_theme_support( 'wp-block-styles' );
    add_theme_support( 'align-wide' );
    add_theme_support( 'responsive-embeds' );

    // Register navigation menus.
    register_nav_menus( array(
        'primary' => esc_html__( 'Primary Menu', 'smartmart' ),
        'footer'  => esc_html__( 'Footer Menu', 'smartmart' ),
    ) );
}
add_action( 'after_setup_theme', 'smartmart_setup' );

/**
 * Enqueue styles and scripts.
 */
function smartmart_enqueue_assets() {
    // Google Fonts.
    wp_enqueue_style(
        'smartmart-google-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:wght@700&display=swap',
        array(),
        SMARTMART_VERSION
    );

    // Main stylesheet.
    wp_enqueue_style( 'smartmart-style', get_stylesheet_uri(), array(), SMARTMART_VERSION );

    // Navigation script.
    wp_enqueue_script(
        'smartmart-navigation',
        get_template_directory_uri() . '/assets/js/navigation.js',
        array(),
        SMARTMART_VERSION,
        true
    );

    // Comment reply.
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'smartmart_enqueue_assets' );

/**
 * Register widget areas.
 */
function smartmart_widgets_init() {
    register_sidebar( array(
        'name'          => esc_html__( 'Sidebar', 'smartmart' ),
        'id'            => 'sidebar-1',
        'description'   => esc_html__( 'Main sidebar widget area.', 'smartmart' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => esc_html__( 'Footer Widgets', 'smartmart' ),
        'id'            => 'sidebar-footer',
        'description'   => esc_html__( 'Footer widget area.', 'smartmart' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ) );

    if ( class_exists( 'WooCommerce' ) ) {
        register_sidebar( array(
            'name'          => esc_html__( 'Shop Sidebar', 'smartmart' ),
            'id'            => 'sidebar-shop',
            'description'   => esc_html__( 'Widgets for the shop archive page.', 'smartmart' ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h3 class="widget-title">',
            'after_title'   => '</h3>',
        ) );
    }
}
add_action( 'widgets_init', 'smartmart_widgets_init' );

/**
 * WooCommerce: Remove default styles.
 */
add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

/**
 * WooCommerce: Custom product grid columns.
 */
function smartmart_loop_columns() {
    return 4;
}
add_filter( 'loop_shop_columns', 'smartmart_loop_columns' );

/**
 * WooCommerce: Products per page.
 */
function smartmart_products_per_page() {
    return 20;
}
add_filter( 'loop_shop_per_page', 'smartmart_products_per_page' );

/**
 * Body classes.
 *
 * @param array $classes Body classes.
 * @return array
 */
function smartmart_body_classes( $classes ) {
    $classes[] = 'smartmart-theme';

    if ( class_exists( 'WooCommerce' ) && ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) ) {
        $classes[] = 'woocommerce-active';
    }

    return $classes;
}
add_filter( 'body_class', 'smartmart_body_classes' );

/**
 * WooCommerce: Cart fragments for AJAX cart refresh.
 */
function smartmart_cart_fragment( $fragments ) {
    ob_start();
    ?>
    <span class="header-cart-count">
        <?php echo WC()->cart ? (int) WC()->cart->get_cart_contents_count() : 0; ?>
    </span>
    <?php
    $fragments['.header-cart-count'] = ob_get_clean();
    return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'smartmart_cart_fragment' );

/**
 * WooCommerce: HPOS compatibility.
 */
add_action( 'before_woocommerce_init', function () {
    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
    }
} );

/**
 * Starter Content - Sets up default homepage, menus, widgets, and theme mods.
 */
function smartmart_starter_content() {
    $starter_content = array(
        // Default widgets
        'widgets' => array(
            'sidebar-shop' => array(
                'woocommerce_price_filter-1' => array(
                    'title' => __( 'Filter by Price', 'smartmart' ),
                ),
                'woocommerce_product_categories-1' => array(
                    'title' => __( 'Categories', 'smartmart' ),
                    'count' => 1,
                    'hierarchical' => 1,
                    'dropdown' => 0,
                ),
                'woocommerce_rating_filter-1' => array(
                    'title' => __( 'Average Rating', 'smartmart' ),
                ),
            ),
            'sidebar-footer' => array(
                'text-1' => array(
                    'title' => __( 'Shop', 'smartmart' ),
                    'text'  => '<ul><li><a href="#">' . __( 'All Products', 'smartmart' ) . '</a></li><li><a href="#">' . __( 'Organic Produce', 'smartmart' ) . '</a></li><li><a href="#">' . __( 'Pantry Staples', 'smartmart' ) . '</a></li></ul>',
                ),
                'text-2' => array(
                    'title' => __( 'Company', 'smartmart' ),
                    'text'  => '<ul><li><a href="#">' . __( 'About Us', 'smartmart' ) . '</a></li><li><a href="#">' . __( 'Sustainability', 'smartmart' ) . '</a></li><li><a href="#">' . __( 'Contact', 'smartmart' ) . '</a></li></ul>',
                ),
                'text-3' => array(
                    'title' => __( 'Support', 'smartmart' ),
                    'text'  => '<ul><li><a href="#">' . __( 'Shipping Info', 'smartmart' ) . '</a></li><li><a href="#">' . __( 'Returns', 'smartmart' ) . '</a></li><li><a href="#">' . __( 'FAQ', 'smartmart' ) . '</a></li></ul>',
                ),
            ),
        ),

        // Default navigation menus
        'nav_menus' => array(
            'primary' => array(
                'name'  => __( 'Primary Menu', 'smartmart' ),
                'items' => array(
                    'page_home' => array(
                        'type'  => 'post_type',
                        'object' => 'page',
                        'title' => __( 'Home', 'smartmart' ),
                    ),
                    'link_shop' => array(
                        'title' => __( 'Shop', 'smartmart' ),
                        'url'   => '#',
                    ),
                    'page_about' => array(
                        'title' => __( 'Collections', 'smartmart' ),
                        'url'   => '#',
                    ),
                ),
            ),
        ),

        // Default theme mods
        'theme_mods' => array(
            'custom_logo' => '',
            'blogname'    => __( 'SmartMart', 'smartmart' ),
            'blogdescription' => __( 'Premium Groceries &amp; Household', 'smartmart' ),
        ),
    );

    return $starter_content;
}
add_filter( 'theme_starter_content', 'smartmart_starter_content' );


/**
 * Ensure prices display in USD ($).
 *
 * @param string $currency_symbol The current currency symbol.
 * @param string $currency        The currency code.
 * @return string USD symbol.
 */
function smartmart_usd_currency_symbol( $currency_symbol, $currency ) {
    if ( 'USD' === $currency ) {
        return '<span class="woocommerce-Price-currencySymbol">$</span>';
    }
    return $currency_symbol;
}
add_filter( 'woocommerce_currency_symbol', 'smartmart_usd_currency_symbol', 10, 2 );
