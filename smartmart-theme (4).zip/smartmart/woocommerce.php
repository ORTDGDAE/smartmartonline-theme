<?php
/**
 * The template for displaying WooCommerce pages
 *
 * @package SmartMart
 */

get_header(); ?>

<div id="primary" class="container site-content">
    <main id="main" class="site-main">
        <?php woocommerce_content(); ?>
    </main>
</div>

<?php get_footer(); ?>
