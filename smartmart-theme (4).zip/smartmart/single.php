<?php
/**
 * The template for displaying single posts
 *
 * @package SmartMart
 */

get_header(); ?>

<div id="primary" class="container site-content">
    <main id="main" class="site-main">
        <?php while ( have_posts() ) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class( 'max-w-3xl' ); ?>>
                <header class="entry-header">
                    <?php the_category( ' ' ); ?>
                    <h1 class="entry-title"><?php the_title(); ?></h1>
                    <div class="entry-meta">
                        <span><?php echo esc_html( get_the_date() ); ?></span>
                        <span>&bull;</span>
                        <span><?php the_author(); ?></span>
                    </div>
                </header>

                <?php if ( has_post_thumbnail() ) : ?>
                    <div class="post-thumbnail">
                        <?php the_post_thumbnail( 'large' ); ?>
                    </div>
                <?php endif; ?>

                <div class="entry-content">
                    <?php the_content(); ?>
                    <?php
                    wp_link_pages( array(
                        'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'smartmart' ),
                        'after'  => '</div>',
                    ) );
                    ?>
                    <?php the_tags( '<div class="post-tags">' . esc_html__( 'Tags:', 'smartmart' ) . ' ', ', ', '</div>' ); ?>
                </div>

                <?php if ( comments_open() || get_comments_number() ) : ?>
                    <div class="entry-comments">
                        <?php comments_template(); ?>
                    </div>
                <?php endif; ?>
            </article>
        <?php endwhile; ?>
    </main>
</div>

<?php get_footer(); ?>
