<?php
/**
 * Template for search form
 *
 * @package SmartMart
 */
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <label>
        <span class="screen-reader-text"><?php echo esc_html_x( 'Search for:', 'label', 'smartmart' ); ?></span>
        <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <circle cx="11" cy="11" r="8"/>
            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <input type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Search premium groceries&hellip;', 'placeholder', 'smartmart' ); ?>" value="<?php echo get_search_query(); ?>" name="s" />
    </label>
    <button type="submit" class="search-submit screen-reader-text"><?php echo esc_html_x( 'Search', 'submit button', 'smartmart' ); ?></button>
</form>
