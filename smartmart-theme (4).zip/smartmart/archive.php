<?php
/**
 * The template for displaying archive pages
 *
 * @package SmartMart
 */

get_header(); ?>

<div id="primary" class="container site-content">
    <main id="main" class="site-main">

        <header class="page-header">
            <?php
            the_archive_title( '<h1 class="page-title">', '</h1>' );
            the_archive_description( '<div class="archive-description">', '</div>' );
            ?>
        </header>

        <?php if ( have_posts() ) : ?>
            <div class="posts-grid">
                <?php while ( have_posts() ) : the_post(); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>
                        <?php if ( has_post_thumbnail() ) : ?>
                            <div class="post-thumbnail">
                                <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'medium' ); ?></a>
                            </div>
                        <?php endif; ?>

                        <div class="post-card-content">
                            <h2 class="entry-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h2>
                            <div class="entry-meta">
                                <span><?php echo esc_html( get_the_date() ); ?></span>
                                <span><?php esc_html_e( 'by', 'smartmart' ); ?> <?php the_author(); ?></span>
                            </div>
                            <div class="entry-summary"><?php the_excerpt(); ?></div>
                            <a href="<?php the_permalink(); ?>" class="btn-smartmart btn-smartmart-outline"><?php esc_html_e( 'Read More', 'smartmart' ); ?></a>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>

            <?php the_posts_pagination(); ?>

        <?php else : ?>
            <p><?php esc_html_e( 'No posts found.', 'smartmart' ); ?></p>
        <?php endif; ?>

    </main>
</div>

<?php get_footer(); ?>
